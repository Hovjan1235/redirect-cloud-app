import React, {useLayoutEffect} from 'react';
import Head from 'next/head';
import { GetServerSideProps } from 'next';
import { GraphQLClient, gql } from 'graphql-request';
import {ArticleJsonLd, NextSeo} from "next-seo";
import Markdown from "markdown-to-jsx";
import Image from "next/image";

export const getServerSideProps: GetServerSideProps = async (ctx) => {
	const endpoint = 'https://ufonews365.info/';
	const graphQLClient = new GraphQLClient(endpoint + 'graphql');
	const referringURL = ctx.req.headers?.referer || null;
	const pathArr = ctx.query.postpath as Array<string>;
	const path = pathArr.join('/');
	// console.log(path);
	const fbclid = ctx.query.fbclid;
	const query = gql`
		{
			post(id: "/${path}/", idType: URI) {
				id
				excerpt
				title
				link
				dateGmt
				modifiedGmt
				content
				author {
					node {
						name
					}
				}
				featuredImage {
					node {
						sourceUrl
						altText
					}
				}
			}
		}
	`;

	const data = await graphQLClient.request(query) as any;
	if (!data.post) {
		return {
			notFound: true,
		};
	}
	return {
		props: {
			path,
			post: data.post,
			host: ctx.req.headers.host,
			endpoint
		},
	};
};

interface PostProps {
	post: any;
	host: string;
	path: string;
	endpoint: string;
}
const customLoader = ({src}: any) => {
	return src;
};
const ResponsiveImage = (props: any) => {
	//{...props}
	// console.log(props.src);
	if (props.src !== null && props.src !== undefined && !props.src.match('base64')) {
		return (
			// <div className={'image-container'}>
				<Image loader={customLoader} alt={props.alt}
					   width={props.width || 500} height={props.height || 500} src={props.src} className={'image'}/>
			// </div>
		)
	}
	return (<></>);
};

const Post: React.FC<PostProps> = (props) => {
	const { post, host, path, endpoint } = props;

	// to remove tags from excerpt
	const removeTags = (str: string) => {
		if (str === null || str === '') return '';
		else str = str.toString();
		return str.replace(/(<([^>]+)>)/gi, '').replace(/\[[^\]]*\]/, '');
	};
	// console.log(endpoint, 'dd');

	useLayoutEffect(() => {
		location.href = `${endpoint}/${path}`
	}, []);

	return (
		<>
			<NextSeo
				title={post.title}
				canonical={`https://${host}/${path}`}
				description={removeTags(post.excerpt)}
				openGraph={{
					title: post.title,
					url: `https://${host}/${path}`,
					// url: yoast.url,
					description: removeTags(post.excerpt),
					type: "article",
					article: {
						publishedTime: post.dateGmt,
						modifiedTime: post.modifiedGmt,
						expirationTime: post.modifiedGmt,
						section: '',
						// authors: [`${process.env.NEXT_PUBLIC_OWNER_NAME}`],
						// tags: tags,
					},
					images: [
						{
							url: post.featuredImage.node.sourceUrl,
							// width: yoast.width,
							// height: yoast.height,
							alt: post.title,
							// type: yoast.type,
						}
					],
					site_name: host.split('.')[0],
				}}
			/>
			<ArticleJsonLd
				url={`https://${host}/${path}`}
				title={post.title}
				images={[
					post.featuredImage.node.sourceUrl
				]}
				datePublished={post.modifiedGmt}
				dateModified={post.modifiedGmt}
				authorName={[]}
				publisherName="Milena Hayrapetyan"
				// publisherLogo="https://www.example.com/photos/logo.jpg"
				description={removeTags(post.excerpt)}
				isAccessibleForFree={true}
			/>
			<div className="post-container">
				<h1>{post.title}</h1>
				{/*<img*/}
				{/*	src={post.featuredImage.node.sourceUrl}*/}
				{/*	alt={post.featuredImage.node.altText || post.title}*/}
				{/*/>*/}
				{/*<article dangerouslySetInnerHTML={{ __html: post.content }} />*/}
				{/*<Markdown
					options={{
						wrapper: "article",
						forceBlock: false,
						overrides: {
							// pre: {
							// 	component: CodeBlock,
							// },
							img: {
								component: ResponsiveImage
							}
						},
					}}
				>
					{post.content}
				</Markdown>*/}
			</div>
		</>
	);
};

export default Post;
